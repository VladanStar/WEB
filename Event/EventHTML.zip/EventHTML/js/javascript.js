function toggleBackground() {
    document.querySelector("body").classList.toggle("active");
}

function toggleBackgroundOff() {
    document.querySelector("button").removeAttribute("onclick");
}